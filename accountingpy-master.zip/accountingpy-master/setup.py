from distutils.core import setup

setup(
    name = 'accountingpy',
    packages = ['accountingpy'],
    version = '0.0.1',   
    description = 'AccountingPy Module Provides a set Of Interactive Functions to Compute the Most Time Consuming Accounting Formulas',
    author = 'ahmed El-sahooly',
    author_email = 'ahmedelsahooly2015@gmail.com',
    url = 'https://github.com/ahmedelsahouly/accountingpy',
    download_url = 'https://github.com/ahmedelsahouly/accountingpy.git',
    keywords = ['tag1', 'tag2'],
    classifiers = [],
)